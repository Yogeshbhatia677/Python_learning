import random
import hangman_words
import hangman_art
print(hangman_art.logo+"\n")
word_list = hangman_words.word_list
stages =hangman_art.stages
 

chosen_word=random.choice(word_list)

live=6
leng=len(chosen_word)
print(f"Length of word={leng}")
List = []
leng2=leng
while(leng2>0):
  leng2=leng2-1
  List.append("_")
print(List)
leng2=leng




while("_" in List):
  guess=input("Guess a Letter!!")
  guess=guess.lower()
  leng3=0
  c=0
  if guess in List:
      print(f"You Have already entered {guess}")
  for x in chosen_word:
    if guess in chosen_word[leng3]:
      c=1 #counter to check if found any letter in #chosenword
      #print("Yess")
      List[leng3]=guess
    leng3=leng3+1
  if c==0:
      print(stages[live])
      print(f"Letter {guess} not in word !! You Lost Live")
      live=live-1
      
    
  print(List)
  
  if live<0:
    break
  #end of while loop
if "_" not  in List:
  print("Hey You Won!!")
else :
  print("You loose!!")
  print(f"The Word is {chosen_word}")
